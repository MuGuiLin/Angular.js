module.exports = {
  name: 'installation'
};